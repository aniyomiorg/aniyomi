var EXTS = [
    ["3g2","3gp","aaf","asf","avchd","avi","drc","flv","m2ts","ts","m2v","m4p","m4v","mkv","mng","mov","mp2","mp4","mpe","mpeg","mpg","mpv","mxf","nsv","ogg","ogv","qt","rm","rmvb","roq","svi",".vob","webm","wmv","yuv"],
    ["aac","aiff","ape","au","flac","gsm","it","m3u","m4a","mid","mod","mp3","mpa","pls","ra","s3m","sid","wav","wma","xm"]
];
var PLAY = {
    html5x: ["HTML5X", "http://msx.benzac.de/plugins/html5x.html?url=", "panel:request:player:options"],
    hls:    ["HLS.js", "http://msx.benzac.de/plugins/hls.html?url=", ""],
    videojs:["Video.js", "http://msx.benzac.de/plugins/videojs.html?url=", ""],
    android:["Android", "http://msx.benzac.de/plugins/android.html?url=", ""],
    netcast:["Netcast", "", "system:netcast:menu"],
    tizen:  ["Tizen", "", "content:request:interaction:tizen"],
    samsung:["Samsung", "", ""],
    hbbtv:  ["HbbTV", "", ""]

};
var BACK = "https://source.unsplash.com/random/";
var ADDR = window.location.origin;
function SETS(k, c){
    var v = TVXServices.storage.getBool(k, false);
    if(c) TVXServices.storage.set(k, v = !v);
    return v;
}
function SIZE(s){
    var i = s == 0 ? 0 : Math.floor(Math.log(s) / Math.log(1024));
    return (s / Math.pow(1024, i)).toFixed(2) * 1 + ' ' + ['B', 'kB', 'MB', 'GB', 'TB'][i];
};
function OPTS(r, g, y){
    var o = {headline: "{dic:caption:options|Options}:", template: {enumerate: false, type: "control", layout: "0,0,8,1"}, items: []},
        k = ["red", "green", "yellow"];
    o.caption = o.headline;
    for(var i = 0; i < 3 && i < arguments.length; i++) if(arguments[i]){
        arguments[i].key = k[i];
        arguments[i].icon = "msx-" + k[i] + ":stop";
        o.items.push(arguments[i]);
        o.caption += "{tb}{ico:" + arguments[i].icon + "} " + arguments[i].label;
    }
    if(o.items.length == 0) return null;
    o.items.push({icon: "msx-blue:menu", label: "{dic:caption:menu|Menu}", action: "[cleanup|menu]"});
    return o
}
function IMDB(f, i){TVXServices.ajax.get("imdb" + (i ? ("/" + i) : ""), {success: function(i){f(i)}, error: function(){f()}})}
function Torrent() {
    var player = {
            list: ["html5x", "hls", "videojs"],
            default: "html5x",
            current: function(p){
                if(p) TVXServices.storage.set("player", p); 
                return p || TVXServices.storage.getFullStr("player", this.default);
            }
        },
        trn = null,
        tizen = null,
        torrents = Torrents ? new Torrents() : null;
    var torrent = function(d, a){
        var fs = [], ds = [], ct = SETS("compress"), sf = SETS("folders"), is = 0;
        d.file_stats.forEach(function(f){
            var b = f.path.indexOf("/"), e = f.path.lastIndexOf("/");
            f.path = [f.path.substr(e + 1), b > 0 && e > b ? f.path.substr(b + 1, e - b - 1) : ""];
            if((e = f.path[0].lastIndexOf(".")) < 0 || !(e = f.path[0].substr(e + 1))) return;
            for(b = 0; b < EXTS.length; b++) if(EXTS[b].indexOf(e) >= 0) break;
            if(b < EXTS.length) b = [{i: "movie", t: "video"}, {i: "audiotrack", t: "audio"}][b];
            else return;
            e = d.hash + "." + f.id;
            if(f.path[1] && (ds.length == 0 || ds[ds.length - 1].label != f.path[1])){
                ds.push({label: f.path[1], action: "[cleanup|focus:" + e + "]"});
                if(sf) fs.push({type:"space", label: "{col:msx-yellow}{ico:folder} " + f.path[1]});
            }
            is++;
            fs.push({
                id: e,
                icon: "msx-green:" + b.i,
                label: f.path[0],
                extensionLabel: SIZE(f.length),
                group: "{dic:label:" + b.t + "|" + b.t + "}",
                folder: f.path[1] ? ("{ico:msx-yellow:folder} " + f.path[1] + "{br}") : "",
                action: b.t + ":resolve:request:interaction:" + b.t + ":" + e + "@" + window.location.href
            });
        });
        return {
            type: "list", headline: d.title, extension: "{ico:msx-white:list} " + is, compress: ct, items: fs, flag: "torrent",
            options: OPTS(null,
                a ? {label: "{dic:save|Save the torrent}", action: "execute:request:interaction:save@" + window.location.href} : null,
                ds.length > 1 ? {label: "{dic:folder|Select folder}", action: "panel:data", data: {
                    type: "list", headline: "{dic:folder|Select folder}:", compress: true, items: ds,
                    template: {type: "control", icon: "folder", layout: "0,0,10,1"}
                }} : null
            ),
            template: {
                type: "control", layout: ct ? "0,0,16,1" : "0,0,12,1", playerLabel: d.title, progress: -1,
                live: {type: "playback", action: "player:show"}, 
                properties: {
                    "info:text": "{context:folder}{ico:{context:icon}} {context:label}",
                    "info:image": d.poster || "default",
                    "control:type": "extended",
                    "resume:key": "id",
                    "trigger:complete": "[player:auto:next|resume:cancel]"
                }
            }
        }
    }
    var resolve = function(u){
        var p = null;
        if(u.length > 6) switch(u.substr(0, 6)){
            case "audio:": p = {"trigger:load": "interaction:commit:message:background:get", "button:content:enable": "false"};
            case "video:": if((u = u.substr(6).split(".", 2)).length == 2){
                u = [ADDR, "play", u[0], u[1]].join("/");
                if(!p){
                    var c = player.current();
                    p = {"button:content:icon": "settings", "button:content:action": "panel:request:interaction:player@" + window.location.href}
                    if(c == "html5x") p["html5x:cors"] = false;
                    else if(c == "tizen" && tizen) tizen.applyPreferences(p);
                    if(PLAY[c][1]) u = "plugin:" + PLAY[c][1] + TVXTools.strToUrlStr(u);
                }
                return {url: u, properties: p};
            }
        }
        return {error: "Wrong request ID!"};
    };
    this.init = function(){
        var p = TVXServices.urlParams.getFullStr("platform", "");
        switch(p){
            case "tizen": 
                tizen = new TizenPlayer();
                tizen.enableBufferSizes();
            case "samsung":
            case "netcast":
            case "hbbtv":
                player.default = p;
            case "android":
                player.list.unshift(p);
        }
        ADDR = TVXServices.urlParams.getFullStr("address", ADDR);
        BACK += TVXServices.urlParams.getFullStr("screen", "");
    };
    this.handleData = function(d){
        switch(d.message){
            case "player":
                player.current(d.data);
                TVXInteractionPlugin.executeAction("[reload:panel|player:auto:goto:current]");
                break;
            case "background:set":
                d = false;
            case "background:get":
                var b = SETS("background", !d);
                TVXInteractionPlugin.executeAction("[player:button:content:setup|player:background:" + (
                    b ? (BACK + "?ts=" + TVXDateTools.getTimestamp() + "#msx-keep-ratio]") : "default]" 
                ),{
                    enable: true,
                    icon: b ? "hide-image" : "image",
                    action: "interaction:commit:message:background:set"
                });        
                break;
            default: if(torrents) torrents.handleData(d);
        }
    };
    this.handleRequest = function(i, d, f){
        switch(i){
            case "player":
                var c = player.current(), r = {
                    type: "list", reuse: false, cache: false, restore: false, headline: "{dic:caption:player|Player}:",
                    template: {type: "control", layout: "0,0,8,1", action: "interaction:commit:message:player", data: "{context:id}"},
                    items: player.list.map(function(p){return {id: p, label: PLAY[p][0] || p, extensionIcon: "radio-button-o" + (p == c ? "n" : "ff")}})
                };
                r.items.push({type: "space"}, {
                    icon: "build", 
                    label: "{dic:caption:options|Options}", 
                    action: "[cleanup|" + PLAY[c][2] + "]",
                    enable: PLAY[c][2] ? true : false
                });
                f(r);
                break;
            case "tizen":
                if(!tizen || !tizen.handleRequest("tizen", "init", f)) f();
                break;
            case "save":
                trn.save_to_db = true;
                TVXServices.ajax.post(ADDR + '/torrents', TVXTools.serialize(trn), {
                    success: function(t){
                        trn = {link: t.hash};
                        f({action: "[cleanup|replace:content:torrent:request:interaction:torrent@" + window.location.href + "]"})
                    },
                    error: function(e){
                        delete trn.save_to_db; 
                        f({action: "error:" + e})
                    }
                });
                break;
            case "torrent":
                if(d && d.data){
                    trn = {};
                    ["link", "title", "poster", "action"].forEach(function(k){if(d.data[k]) trn[k] = d.data[k]});
                    if(d.data.group) trn.data = "GRP:" + d.data.group;
                    var r = function(i){
                        if(i) trn.poster = i;
                        f({action: "content:request:interaction:torrent@" + window.location.href});
                    }
                    if(trn.poster || !d.data.imdbid) r();
                    else IMDB(r, d.data.imdbid);
                } else TVXServices.ajax.get(
                    ADDR + "/stream/?stat" + ["link", "title", "poster"].map(function(k){
                        return trn[k] ? ("&" + k + "=" + TVXTools.strToUrlStr(trn[k])) : "";
                    }).join(""), {
                        success: function(t){f(torrent(t, trn.action == "add"))},
                        error: function(e){TVXInteractionPlugin.error(e); f();}
                    }
                );
                break;
            default: if(!torrents || !torrents.handleRequest(i, f)) f(resolve(i));
        }
    }
}
TVXPluginTools.onReady(function() {
    TVXInteractionPlugin.setupHandler(new Torrent());
    TVXInteractionPlugin.init();
});
