TVXPluginTools.onReady(function() {
    TVXInteractionPlugin.setupHandler({handleRequest: function(i, d, f){
        TVXInteractionPlugin.onValidatedSettings(function(){
            var a = TVXServices.urlParams.getFullStr("address", "");
            if(a) a = "&address=" + TVXTools.strToUrlStr(a);
            f({
                name: "TorrServer Plugin",
                version: "0.0.5",
                dictionary: TVXServices.storage.getBool("russian", false) ? (window.location.origin + "/msx/russian.json") : null,
                reference: "request:interaction:menu@" + window.location.origin 
                    + "/msx/torrents?platform=" + TVXSettings.PLATFORM 
                    + "&screen=" + TVXSettings.SCREEN_WIDTH + "x" + TVXSettings.SCREEN_HEIGHT 
                    + a
            });
        });
    }});
    TVXInteractionPlugin.init();
});
